# CPU-Scheduling-Python

To run this project, <br>
cd Calculator <br>
python app.py

Go to the provided link.
